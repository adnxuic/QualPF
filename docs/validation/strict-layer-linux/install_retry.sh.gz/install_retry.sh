#!/bin/bash
set -euo pipefail
cd /source
python3 -B /results/runtime_smoke.py /build/install portable portable-03 >/results/linux-gnu-installed-runtime-03.log 2>&1
python3 -B /source/tools/validation/check_zero_fortran.py --build /build --objdump /usr/bin/objdump --nm /usr/bin/nm --output /results/linux-gnu-zero-fortran.json >/results/linux-gnu-zero-fortran.log 2>&1
tail -n 3 /results/linux-gnu-installed-runtime-03.log
tail -n 2 /results/linux-gnu-zero-fortran.log
