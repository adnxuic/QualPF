#!/bin/bash
set -euo pipefail
cd /source
python3 -B /results/package_binding.py >/results/linux-gnu-package-binding.log 2>&1
python3 -B /source/tools/architecture/check_strict_boundaries.py --graph /build/strict-targets.json --self-test --output /results/strict-deb.json >/results/linux-gnu-strict-deb.log 2>&1
python3 -B /source/tools/validation/check_zero_fortran.py --build /build --objdump /usr/bin/objdump --nm /usr/bin/nm --output /results/linux-gnu-packaged-zero-fortran.json >/results/linux-gnu-packaged-zero-fortran.log 2>&1
python3 -B /source/tools/validation/check_references.py >/results/linux-gnu-final-references.log 2>&1
cat /results/linux-gnu-package-binding.log
tail -n 2 /results/linux-gnu-packaged-zero-fortran.log
