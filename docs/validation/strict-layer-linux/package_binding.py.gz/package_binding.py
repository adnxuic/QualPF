import hashlib
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys

sys.path.insert(0,'/source/tools/architecture')
from check_boundaries import source_manifest
raw = Path('/results')
assert source_manifest() == json.loads((raw/'source-inputs.json').read_bytes())
before = json.loads((raw/'linux-gnu-commands.json').read_bytes())
after = json.loads(Path('/build/compile_commands.json').read_bytes())
assert before == after, 'Packaging changed compilation inputs'
old_tests = json.loads((raw/'linux-gnu-normal-list.json').read_bytes())['tests']
new_tests = json.loads(subprocess.check_output(['ctest','--test-dir','/build','-L','normal','--show-only=json-v1']))['tests']
for key in ('name','command','properties'):
    assert [item[key] for item in old_tests] == [item[key] for item in new_tests], key
executables = {'validated_stage':Path('/build/install/bin/qualpf'),
               'deb_build':Path('/build/src/qualpf'),
               'deb_installed':Path('/build/deb-installed/usr/bin/qualpf')}
text, permissions, rpaths = {}, {}, {}
for name,file in executables.items():
    output = Path('/build/tmp', name+'.text.bin')
    subprocess.run(['objcopy','--only-section=.text','-O','binary',str(file),str(output)],check=True)
    text[name] = hashlib.file_digest(output.open('rb'),'sha256').hexdigest()
    rpaths[name] = subprocess.check_output(['readelf','-d',str(file)],text=True)
    permissions[name] = oct(stat.S_IMODE(file.stat().st_mode))
    assert stat.S_IMODE(file.stat().st_mode) & 0o111 == 0o111
    assert not re.search(r'R(?:UN)?PATH.*(?:/source|/build)',rpaths[name])
assert len(set(text.values())) == 1, 'DEB packaging changed executable code'
for prefix in (Path('/build/install'),Path('/build/deb-installed/usr')):
    for file in (prefix/'share/qualpf').rglob('*'):
        if file.is_file():
            assert stat.S_IMODE(file.stat().st_mode) & 0o444 == 0o444
shutil.copyfile('/build/CMakeCache.txt',raw/'linux-gnu-deb-cache.txt')
report = dict(status='PASS',source_inputs_unchanged=True,compile_commands_unchanged=True,
              compile_units=len(after),normal_test_commands_properties_unchanged=True,
              normal_test_count=len(new_tests),executable_text_sha256=text,
              executable_modes=permissions,rpaths=rpaths,
              resource_permissions='All installed resources readable by owner/group/other',
              package_rebuild_scope='Link only; existing C++ object compilation inputs unchanged')
(raw/'package-binding.json').write_text(json.dumps(report,indent=2)+'\n')
extra = dict(python=sys.version,fortran_compiler=shutil.which('gfortran'),
             fortran_executable_candidates=[str(p) for p in Path('/usr/bin').glob('*gfortran*')])
(raw/'environment-runtime.json').write_text(json.dumps(extra,indent=2)+'\n')
print('PASS: DEB/staged executable .text identical; 322 compile commands and 86 normal test commands/properties unchanged; installed permissions/RPATH checked')
