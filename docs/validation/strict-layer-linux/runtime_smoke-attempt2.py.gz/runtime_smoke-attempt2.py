import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys

prefix = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
attempt = sys.argv[3] if len(sys.argv) > 3 else mode
executable = prefix / 'bin/qualpf'
task = Path('/build') / ('runtime-smoke-' + attempt)
task.mkdir(exist_ok=False)
cif = task / 'cif inputs'
cif.mkdir()
shutil.copyfile('/source/tests/data/cif/cod-2300112.cif', cif / 'cod-2300112.cif')
database = task / 'database/cards'
database.parent.mkdir()
settings = task / 'settings'
(settings / 'IC').mkdir(parents=True)
(settings / 'IC/qualpf.ini').write_text(
    '[databases]\ncount=1\n0\\inUse=true\n0\\name=cod_inorg\n0\\path=' + database.as_posix()
    + '\ndefaultDir=' + database.parent.as_posix()
    + '\n[maintenance]\nsettingsMigrationV1=true\n', encoding='utf8')
pool = json.loads(Path('/source/tests/data/current-preprocessing-pool.qxp').read_bytes())['diffraction_data']
pattern = task / 'finite input.xy'
pattern.write_text(''.join(f'{x:.17g} {y:.17g}\n' for x,y in zip(pool['x'],pool['original_observed'])))
environment = os.environ.copy()
for key in ('LD_LIBRARY_PATH','QT_PLUGIN_PATH','QML2_IMPORT_PATH','DISPLAY'):
    environment.pop(key, None)
environment.update(LD_DEBUG='libs', QT_DEBUG_PLUGINS='1', QT_QPA_PLATFORM='offscreen',
                   QUALPF_SEARCH_BACKEND='cpp', QUALPF_PREPROCESSING_BACKEND='cpp')
report = dict(status='FAIL', mode=mode, installed_executable=str(executable),
              executable_sha256=hashlib.file_digest(executable.open('rb'),'sha256').hexdigest(),
              sdk_paths_in_runtime_environment=False, cases=[], loaded_libraries={},
              recursive_providers={}, resource_files=[])
try:
    gui_platform = 'xcb' if mode == 'portable' else 'offscreen'
    cases = [
        ('version', ['--nogui','--version'], None),
        ('sqlite_create', ['--nogui','--createdb','--cifdir',str(cif),'--dbout',str(database)], None),
        ('cli_metadata', ['--nogui','--search','--composition','Zn'], None),
        ('gui_search', ['--auto','--search','--composition','Zn'], gui_platform),
        ('gui_pattern', ['--auto',str(pattern)], gui_platform),
        ('gui_xcb_search', ['--auto','--search','--composition','Zn'], 'xcb'),
    ]
    loaded = set()
    for name, arguments, platform in cases:
        case_environment = dict(environment)
        if platform:
            case_environment['QT_QPA_PLATFORM'] = platform
        command = [str(executable),'--settings-dir',str(settings),*arguments]
        if platform == 'xcb':
            command = ['xvfb-run','-a','-s','-screen 0 1280x800x24',*command]
        completed = subprocess.run(command,env=case_environment,capture_output=True,timeout=45)
        stdout,stderr = completed.stdout.decode('utf8',errors='replace'),completed.stderr.decode('utf8',errors='replace')
        out = Path('/results') / f'{attempt}-{name}.stdout.log'
        err = Path('/results') / f'{attempt}-{name}.stderr.log'
        out.write_bytes(completed.stdout)
        err.write_bytes(completed.stderr)
        report['cases'].append(dict(name=name,command=command,platform=platform,exit_code=completed.returncode,
                                    stdout_log=out.name,stderr_log=err.name))
        assert completed.returncode == 0, (name,completed.returncode,stderr[-4000:])
        if name == 'version':
            assert 'qualpf Version 1.0.5' in stdout
        if name == 'sqlite_create':
            assert 'Done: 1 ok, 0 errors.' in stdout
            assert 'libqsqlite.so' in stderr and 'loaded library' in stderr
            for suffix in ('.sq','.sq.info','.sq.infostat','.sq.search'):
                file = Path(str(database)+suffix)
                assert file.is_file()
                connection = sqlite3.connect(file.as_uri()+'?mode=ro',uri=True)
                assert connection.execute('pragma integrity_check').fetchone() == ('ok',)
                connection.close()
        if name == 'cli_metadata':
            assert 'Found 1 card(s):' in stdout and 'zinc_oxide' in stdout
        if platform:
            assert f'libq{platform}.so' in stderr and 'loaded library' in stderr
        for value in re.findall(r'calling init:\s*(/[^\s]+)',stderr):
            file = Path(value)
            if file.is_file():
                loaded.add(file.resolve())
    forbidden = re.compile(r'gfortran|quadmath|ifcore|ifport|libfortran|flang',re.I)
    providers = {}
    for file in sorted(loaded):
        assert not forbidden.search(str(file)), file
        report['loaded_libraries'][str(file)] = hashlib.file_digest(file.open('rb'),'sha256').hexdigest()
    for file in sorted(loaded | {executable}):
        completed = subprocess.run(['ldd',str(file)],capture_output=True,text=True)
        assert completed.returncode == 0, (str(file),completed.stderr)
        assert 'not found' not in completed.stdout, (str(file),completed.stdout)
        assert not forbidden.search(completed.stdout), (str(file),completed.stdout)
        report['recursive_providers'][str(file)] = completed.stdout
        for name,value in re.findall(r'([^\s]+)\s+=>\s+(/[^\s]+)',completed.stdout):
            providers[name] = str(Path(value).resolve())
    assert any('libqsqlite.so' in str(file) for file in loaded)
    assert any('libqxcb.so' in str(file) for file in loaded)
    qt = [file for file in loaded if file.name.startswith('libQt6')]
    assert qt
    if mode == 'portable':
        assert all(file.is_relative_to(prefix) for file in qt), qt
        assert (prefix/'bin/qt.conf').is_file()
        assert (prefix/'plugins/sqldrivers/libqsqlite.so').is_file()
    elif mode == 'deb':
        assert all(file.is_relative_to(Path('/usr/lib')) for file in qt), qt
    report['rpath'] = subprocess.check_output(['readelf','-d',str(executable)],text=True)
    assert 'ORIGIN/../lib' in report['rpath']
    resources = prefix / 'share/qualpf'
    assert resources.is_dir() and any(resources.rglob('*'))
    for file in sorted(resources.rglob('*')):
        if file.is_file():
            source = Path('/source/share/qualx') / file.relative_to(resources)
            assert file.read_bytes() == source.read_bytes(), file
            report['resource_files'].append(file.relative_to(prefix).as_posix())
    report['loaded_image_count'] = len(loaded)
    report['provider_count'] = len(providers)
    report['status'] = 'PASS'
except Exception as error:
    report['failure'] = str(error)
    raise
finally:
    Path('/results',f'{attempt}-runtime.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',mode,'installed CLI, CIF/SQLite, automatic GUI/search/pattern;',len(loaded),'loaded libraries; no Fortran')
