import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[3]
out=root/'build/milestone-a01/reacceptance'
base=root/'docs/development/repository-consolidation'
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args])
index=json.loads((base/'validation-index.json').read_bytes())
for row in index['files']:
    data=(base/row['path']).read_bytes()
    assert sha(data)==row['stored_sha256'],row['path']
    raw=gzip.decompress(data)
    assert len(raw)==row['original_bytes'] and sha(raw)==row['original_sha256']
    original=root/row['original_path']
    assert original.read_bytes()==raw,row['original_path']
manifest=json.loads((root/'tests/reference/manifest.json').read_bytes())
authority=json.loads(git('show','phase37e-entry-20261009:tests/reference/manifest.json'))
identity=lambda m:Counter((r.get('original_path',r['path']),r['bytes'],r['sha256']) for r in m['files'])
assert len(manifest['files'])==169 and identity(manifest)==identity(authority)
for r in manifest['files']:
    data=(root/r['path']).read_bytes()
    assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['path']
originals={}
for path in ('docs/architecture/milestone-a/independent-review.md','docs/architecture/milestone-a/acceptance-matrix.md','docs/architecture/milestone-a/gate.json'):
    assert not git('diff','b4e506bba0d052c2e3c3f60ef6cce422b48e9a81','--',path).strip()
    originals[path]=sha((root/path).read_bytes())
delta=git('diff','--name-only','e6883edab2fb26d8f22866c0585b910322027c12','5a247152c9a57bdab4f0ba348218dec80044d49c','--','src','apps','cmake','configured','third_party','share','deploy','CMakeLists.txt','CMakePresets.json','.github').decode().splitlines()
assert delta==['apps/qualpf/main.cpp'],delta
result=dict(status='PASS',candidate='5a247152c9a57bdab4f0ba348218dec80044d49c',
    indexed_prior_raw_logs_verified=len(index['files']),references_verified=len(manifest['files']),
    reference_authority='phase37e-entry-20261009:tests/reference/manifest.json',
    original_blocked_records_unchanged=originals,production_build_runtime_delta=delta,
    approved_numerical_contracts_unchanged=True)
(out/'authority.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('PASS: 73 prior raw logs; 169 reference byte identities; original blocked records unchanged; production delta restricted to CLI main')
