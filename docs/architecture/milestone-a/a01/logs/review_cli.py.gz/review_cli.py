"""Independent old/new product observation using the frozen A-01 recipe."""
from contextlib import closing
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--old', type=Path, required=True)
parser.add_argument('--new', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.update(QT_QPA_PLATFORM='offscreen', MKL_NUM_THREADS='1', QUALPF_SEARCH_BACKEND='cpp', QUALPF_PREPROCESSING_BACKEND='cpp')
result = {'status':'FAIL', 'old_sha256':hashlib.sha256(args.old.read_bytes()).hexdigest(),
          'new_sha256':hashlib.sha256(args.new.read_bytes()).hexdigest(), 'observations':[]}
def run(exe, case, settings, tail):
    command = [str(exe), '--nogui', '--settings-dir', str(settings), *tail]
    done = subprocess.run(command, capture_output=True, env=env, timeout=30)
    result['observations'].append({'role':'old' if exe == args.old else 'new', 'case':case,
                                  'command':command, 'exit':done.returncode,
                                  'stdout':done.stdout.decode('utf8',errors='replace'),
                                  'stderr':done.stderr.decode('utf8',errors='replace'),
                                  'stdout_sha256':hashlib.sha256(done.stdout).hexdigest(),
                                  'stderr_sha256':hashlib.sha256(done.stderr).hexdigest()})
    return done
try:
    with tempfile.TemporaryDirectory(prefix='independent-cli-', dir=args.output.parent) as temporary:
        root = Path(temporary).resolve()
        (root/'cif').mkdir()
        shutil.copyfile(args.source/'tests/data/cif/cod-2300112.cif', root/'cif/input.cif')
        databases = {}
        for kind in ['valid','broken']:
            location = root/kind
            location.mkdir()
            db = location/'cards'
            settings = location/'settings'
            (settings/'IC').mkdir(parents=True)
            (settings/'IC/qualpf.ini').write_text('[databases]\ncount=1\n0\\inUse=true\n0\\name=cod_inorg\n0\\path='+db.as_posix()+'\ndefaultDir='+location.as_posix()+'\n[maintenance]\nsettingsMigrationV1=true\n',encoding='utf8')
            databases[kind] = settings
            if kind == 'valid':
                created = run(args.new,'create-valid',settings,['--createdb','--cifdir',str(root/'cif'),'--dbout',str(db)])
                assert created.returncode == 0 and b'Done: 1 ok, 0 errors.' in created.stdout
            else:
                for suffix in ['.sq','.sq.info','.sq.infostat','.sq.search']:
                    with closing(sqlite3.connect(str(db)+suffix)) as connection:
                        connection.execute('CREATE TABLE placeholder(value INTEGER)')
                        if suffix == '.sq':
                            connection.execute('CREATE TABLE infodb(ncard INTEGER,type TEXT)')
                            connection.execute("INSERT INTO infodb VALUES(0,'cod_inorg')")
                        connection.commit()
        data = json.loads((args.source/'tests/data/current-preprocessing-pool.qxp').read_bytes())['diffraction_data']
        pattern = root/'finite.xy'
        pattern.write_text(''.join(f'{x:.17g} {y:.17g}\n' for x,y in zip(data['x'],data['original_observed'])),encoding='utf8')
        for case,kind,tail,expected_exit in [
            ('positive','valid',['--search','--composition','Zn'],0),
            ('empty','valid',['--search','--composition','Xe'],0),
            ('pattern-normal','valid',['--search',str(pattern)],0),
            ('pattern-query-failure','broken',['--search',str(pattern)],1),
        ]:
            before = run(args.old,case,databases[kind],tail)
            after = run(args.new,case,databases[kind],tail)
            assert before.returncode == after.returncode == expected_exit, case
            assert before.stdout == after.stdout, case
            if case.startswith('pattern-'):
                # Existing diagnostic wall-clock timing is observational, not numerical output.
                timing = rb'(?m)^("QualxDbManager::makeQueryStrongest->makeQueryInfoIdsWithFom" elapsed time: )"[0-9]+(?:\.[0-9]+)?"( sec)$'
                result.setdefault('stderr_elapsed_time_normalization', []).append({
                    'case':case, 'old_matches':len(re.findall(timing,before.stderr)),
                    'new_matches':len(re.findall(timing,after.stderr))})
                assert len(re.findall(timing,before.stderr)) == len(re.findall(timing,after.stderr))
                assert re.sub(timing,rb'\1"<clock>"\2',before.stderr) == re.sub(timing,rb'\1"<clock>"\2',after.stderr), case
            else:
                assert before.stderr == after.stderr, case
        before = run(args.old,'A-01',databases['broken'],['--search','--composition','Zn'])
        after = run(args.new,'A-01',databases['broken'],['--search','--composition','Zn'])
        assert before.returncode == 0 and b'Found 0 card(s)' in before.stdout
        assert after.returncode != 0 and b'Found ' not in after.stdout
        assert re.search(rb'Search failed: \S.+',after.stderr)
        result.update(status='PASS', all_stdout_byte_equal=True, stderr_byte_equal_except_existing_elapsed_time=True,
                      original_frozen_recipe_now_fails_correctly=True)
finally:
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('PASS: independent original/fixed CLI comparison; unchanged successful/empty/pattern outputs; A-01 corrected')
