"""Bounded read-only comparison of actual build inputs, artifacts and normal tests."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--build',type=Path,required=True)
parser.add_argument('--platform',required=True)
args = parser.parse_args()
root, source, build, platform = args.root,args.source,args.build,args.platform
out = root/'build/milestone-a01/reacceptance'
prior = root/'build/phase37e/raw'
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
baseline = load(prior/'post-package-source-inputs.json')
allowed = {'apps/qualpf/main.cpp','tests/product/CMakeLists.txt','tests/coverage.json','tests/README.md'}
changed = [p for p,h in baseline.items() if sha(source/p) != h]
assert set(changed) == allowed,changed
new_sources=['tests/product/cli/search_boundary.py','tests/integration/gui/synchronous_search_service_test.cpp']
candidate = root/'build/milestone-a01/review-checkout'
for p in allowed|set(new_sources):
    assert sha(source/p) == sha(candidate/p),p
old_commands=load(prior/(platform+'-commands.json'))
commands=load(build/'compile_commands.json')
serialize=lambda c:json.dumps(c,sort_keys=True)
old_count=Counter(map(serialize,old_commands)); current_count=Counter(map(serialize,commands))
assert not old_count-current_count,'existing compile commands changed'
added=[json.loads(c) for c,n in (current_count-old_count).items() for _ in range(n)]
assert len(added)==2 and all('qualpf_synchronous_search_tests' in c['command'] for c in added),added
pure=[c for c in commands if any('/src/'+s+'/' in c['file'].replace('\\','/') for s in ('core','application'))]
assert len(pure)==70
assert all(not re.search(r'[/\\]include[/\\]Qt|[-/]DQT_|Qt[56]::',c['command']) for c in pure)
previous=load(prior/(platform+'-zero-fortran.json'))['evidence_fingerprints']['binaries']
current_zero=load(out/(platform+'-zero-fortran.json'))
assert current_zero['status']=='PASS'
current=current_zero['evidence_fingerprints']['binaries']
artifact_changes=[p for p,h in previous.items() if sha(build/p)!=h]
assert artifact_changes==['src/qualpf'+('.exe' if platform.startswith('windows') else '')],artifact_changes
assert set(current)-set(previous)=={('' if platform.startswith('windows') else 'tests/')+'qualpf_synchronous_search_tests'+('.exe' if platform.startswith('windows') else '')}
assert all(sha(build/p)==h for p,h in current.items())
old_list=load(prior/(platform+'-normal-list.json'))
current_list=load(out/(platform+'-tests.json'))
def normal(data):
    return {t['name']:t for t in data['tests'] if 'normal' in next((p['value'] for p in t['properties'] if p['name']=='LABELS'),[])}
old_tests=normal(old_list); tests=normal(current_list)
expected=set(load(candidate/'tests/coverage.json')['current_normal_tests'])
assert len(old_tests)==80 and set(tests)==expected and len(tests)==82
assert set(tests)-set(old_tests)=={'qualpf.cli.search_boundary','qualpf.cli.synchronous_boundaries'}
for p,t in old_tests.items():
    assert t['command']==tests[p]['command'] and t['properties']==tests[p]['properties'],p
junit=ET.parse(out/(platform+'-workflows.xml')).getroot()
cases=junit.findall('.//testcase'); fresh={c.attrib['name'] for c in cases}
assert len(cases)==len(fresh)==28
assert not junit.findall('.//failure') and not junit.findall('.//skipped')
assert all(c.attrib.get('status')=='run' for c in cases)
old_junit=ET.parse(prior/(platform+'-tests.xml')).getroot()
assert {c.attrib['name'] for c in old_junit.findall('.//testcase')}==set(old_tests)
assert not old_junit.findall('.//failure') and not old_junit.findall('.//skipped')
reused=set(tests)-fresh
assert len(reused)==54 and reused<=set(old_tests)
cli=load(out/(platform+'-cli.json')); independent=load(out/(platform+'-independent-cli.json'))
product='src/qualpf'+('.exe' if platform.startswith('windows') else '')
assert cli['status']==independent['status']=='PASS' and len(cli['cases'])==8
assert cli['executable_sha256']==independent['new_sha256']==current[product]
assert independent['old_sha256']==previous[product]
result=dict(status='PASS',platform=platform,candidate='5a247152c9a57bdab4f0ba348218dec80044d49c',
    source_inputs_rehashed=len(baseline),authorized_input_delta=changed,added_sources=new_sources,
    compile_units=len(commands),existing_compile_commands_preserved=len(old_commands),
    complete_qtfree_core_application_units=len(pure),commands_sha256=sha(build/'compile_commands.json'),
    binaries_rehashed=len(current),unchanged_original_binaries=len(previous)-1,
    changed_original_binaries=artifact_changes,new_product_sha256=current[product],
    old_product_sha256=previous[product],normal_tests=len(tests),
    fresh_validation=sorted(fresh),reused_unchanged_dependencies=sorted(reused),
    reused_checkpoint='d2915b0bd32b3644b00bc343440dd24548571bd6',
    original_junit_sha256=sha(prior/(platform+'-tests.xml')),
    fresh_junit_sha256=sha(out/(platform+'-workflows.xml')),
    normal_test_commands_and_properties_preserved=True,
    independent_product_cases=len(independent['observations']))
(out/(platform+'-binding.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('PASS:',platform,len(commands),'units;',len(current),'artifacts; 28 fresh + 54 reused normal identities; unchanged commands and qualified inputs')
