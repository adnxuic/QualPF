import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
root=Path('E:/CPlusProject/QualPF') if sys.platform=='win32' else Path('/mnt/e/CPlusProject/QualPF')
out=root/'build/milestone-a01/reacceptance'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sys.platform=='win32':
    qtbase=Path('E:/QualPF-SDK/Qt/6.8.3')
    platforms=[('windows-gnu',root/'build/phase37e/clean-checkout/build/windows-gnu-001',Path('E:/QualPF-SDK/Qt/Tools/mingw1310_64/bin/g++.exe'),qtbase/'mingw_64','13.1.0'),
               ('windows-msvc',root/'build/phase37e/clean-checkout/build/windows-msvc-001',Path('D:/Visual Studio 2022/Community/VC/Tools/MSVC/14.40.33807/bin/Hostx64/x64/cl.exe'),qtbase/'msvc2022_64','19.40.33811.0')]
else:
    sdk=Path('/var/tmp/qualpf-layout-sdk-20261008')
    assert (sdk/'.qualpf-layout-owned').is_file()
    platforms=[('linux-gnu',sdk/'workspace-phase37e/build/linux-gnu-001',sdk/'usr/bin/g++',sdk/'usr','15.2.0')]
result={}
for name,build,compiler,qt,version in platforms:
    candidates=list((build/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'))
    assert len(candidates)==1,candidates
    cmake=candidates[0].read_text()
    actual=re.search(r'set\(CMAKE_CXX_COMPILER_VERSION "([^"]+)"\)',cmake).group(1)
    assert actual==version,(actual,version)
    previous=json.loads((root/'build/phase37e/raw'/(name+'-fingerprint.json')).read_bytes())
    assert sha(candidates[0])==previous['compiler_fingerprint']
    version_files=list(qt.glob('lib/**/Qt6Core/Qt6CoreConfigVersionImpl.cmake'))
    assert len(version_files)==1,version_files
    expected='6.10.2' if name=='linux-gnu' else '6.8.3'
    assert 'set(PACKAGE_VERSION "'+expected+'")' in version_files[0].read_text(),version_files
    result[name]=dict(compiler_version=actual,compiler=str(compiler),compiler_sha256=sha(compiler),
                      unchanged_compiler_configuration_sha256=sha(candidates[0]),
                      qt_version=expected,qt_version_file=str(version_files[0]),qt_version_sha256=sha(version_files[0]))
    if name=='linux-gnu':
        release=(sdk/'etc/os-release').read_text()
        banner=subprocess.check_output(['chroot',str(sdk),'/usr/bin/g++','--version']).decode()
        assert 'VERSION_ID="26.04"' in release and '15.2.0' in banner
        result[name].update(os_release=release,actual_compiler_banner=banner)
(out/('toolchains-windows.json' if sys.platform=='win32' else 'toolchains-linux.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('PASS: actual qualified compiler and Qt inputs',list(result))
