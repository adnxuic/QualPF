from pathlib import Path
import subprocess,re,json,hashlib
root=Path(__file__).resolve().parents[3]
build=root/'build/phase37e/clean-checkout/build/windows-msvc-001'
nm=Path('E:/QualPF-SDK/Qt/Tools/mingw1310_64/bin/nm.exe')
files=sorted(list(build.rglob('*.obj'))+list(build.rglob('*.lib')))
checked=[];skipped=[];matches=[];errors=[];lines=0
for p in files:
    if p.suffix=='.lib' and p.read_bytes()[:8]!=b'!<arch>\n':
        if p.name=='syminfo.lib' and p.read_bytes()==(root/'share/qualx/files/syminfo.lib').read_bytes():
            skipped.append(dict(path=p.relative_to(build).as_posix(),reason='byte-identical runtime crystallographic text table, not an archive'));continue
        errors.append('unknown non-archive '+str(p));continue
    c=subprocess.run([str(nm),str(p)],capture_output=True,text=True,errors='replace')
    if c.returncode: errors.append(str(p)+': '+c.stderr[:200])
    lines+=len(c.stdout.splitlines())
    matches.extend(re.findall(r'\b(?:_+gfortran\w*|_+\w+_MOD_\w+|for_\w+)\b',c.stdout))
    checked.append(dict(path=p.relative_to(build).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
result=dict(status='PASS' if not errors and not matches else 'FAIL',scope='FRESH_MSVC_COFF_AND_STATIC_ARCHIVE_ORIGIN_SCAN',
 objects_archives=len(checked),symbol_lines=lines,fortran_origin_matches=matches,errors=errors,
 checked=checked,non_archive_resources=skipped,scanner_sha256=hashlib.sha256(nm.read_bytes()).hexdigest())
(root/'build/milestone-a01/reacceptance/windows-msvc-static-symbols.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(result['status'],len(checked),'COFF objects/archives;',lines,'actual symbol lines;',len(matches),'Fortran-origin matches')
assert result['status']=='PASS',errors
