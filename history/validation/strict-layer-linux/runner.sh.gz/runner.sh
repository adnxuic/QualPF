#!/bin/bash
set -euo pipefail
mkdir -p /build/home /build/tmp /build/runtime
chmod 700 /build/runtime
cd /source
TASK_ACTION=${1:?action}
run() {
    local task_log=$1
    shift
    printf '%q ' "$@" >> /results/commands.log
    printf '\n' >> /results/commands.log
    "$@" >"/results/$task_log" 2>&1
}
if [ "$TASK_ACTION" = build ]; then
    test ! -f /build/CMakeCache.txt
    test ! -d /build/CMakeFiles
    python3 - <<'PY'
import datetime,hashlib,json,os,pathlib,subprocess,sys
sys.path.insert(0,'/source/tools/architecture')
from check_boundaries import source_manifest
inputs=source_manifest(); expected=json.loads(pathlib.Path('/results/source-inputs.json').read_bytes())
assert inputs==expected, 'SDK snapshot input mismatch'
def command(*args): return subprocess.check_output(args,text=True,stderr=subprocess.STDOUT)
versions=dict(os_release=pathlib.Path('/etc/os-release').read_text(),architecture=command('uname','-m').strip(),compiler=command('g++','--version'),cmake=command('cmake','--version'),ninja=command('ninja','--version'),qt=command('/usr/lib/qt6/bin/qmake','--version'),packages=command('dpkg-query','-W','libeigen3-dev','libboost-dev','libsqlite3-0','libqt6sql6-sqlite','libgtest-dev','patchelf','binutils','python3'),compiler_sha256=hashlib.file_digest(open('/usr/bin/g++','rb'),'sha256').hexdigest(),qt_version_sha256=hashlib.file_digest(open('/usr/lib/x86_64-linux-gnu/cmake/Qt6Core/Qt6CoreConfigVersionImpl.cmake','rb'),'sha256').hexdigest(),fortran_compiler_present=pathlib.Path('/usr/bin/gfortran').exists(),source_input_count=len(inputs),source_inputs_match_windows=True,sdk='/var/tmp/qualpf-layout-sdk-20261008')
pathlib.Path('/results/environment.json').write_text(json.dumps(versions,indent=2)+'\n')
pathlib.Path('/results/linux-gnu-fresh-start.json').write_text(json.dumps(dict(id='linux-gnu',build='/build',cache_existed_before=False,objects_existed_before=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
print('Verified',len(inputs),'unchanged inputs in accepted SDK')
PY
    mkdir -p /build/.cmake/api/v1/query
    touch /build/.cmake/api/v1/query/codemodel-v2
    run linux-gnu-configure.log cmake -S /source -B /build -G Ninja -DCMAKE_BUILD_TYPE=RELEASE -DQUALPF_BUILD_PRODUCT_TESTS=ON -DQUALPF_BUILD_PREPROCESSING_TESTS=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
    run linux-gnu-strict.log python3 -B /source/tools/architecture/check_strict_boundaries.py --graph /build/strict-targets.json --self-test --output /results/strict.json
    run linux-gnu-qualpf-build.log cmake --build /build --target qualpf --parallel 2
    run linux-gnu-build.log cmake --build /build --parallel 2
    run linux-gnu-qtfree-configure.log cmake -S /source/tests/architecture -B /build/qtfree-application -G Ninja -DCMAKE_BUILD_TYPE=RELEASE -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
    run linux-gnu-qtfree-build.log cmake --build /build/qtfree-application --parallel 2
    run linux-gnu-qtfree-test.log ctest --test-dir /build/qtfree-application --output-on-failure --output-junit /results/linux-gnu-qtfree-tests.xml
    run linux-gnu-public-headers.log python3 -B /results/public_headers.py
    run linux-gnu-standalone-configure.log cmake -S /source/tests -B /build/standalone -G Ninja -DCMAKE_BUILD_TYPE=Release -DQUALPF_BUILD_CONTRACT_TESTS=ON -DQUALPF_BUILD_SEARCH_INTEGRATION_TESTS=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
    run linux-gnu-standalone-build.log cmake --build /build/standalone --parallel 2 --target qualpf_contract_tests qualpf_search_integration_tests
    run linux-gnu-standalone-test.log ctest --test-dir /build/standalone -R '^qualpf\.(contracts|search\.integration)$' --output-on-failure --output-junit /results/linux-gnu-standalone-tests.xml
    printf 'Linux clean product and complete Application client builds PASS\n'
elif [ "$TASK_ACTION" = build-check ]; then
    run linux-gnu-qualpf-completion.log cmake --build /build --target qualpf --parallel 2
    run linux-gnu-build-completion.log cmake --build /build --parallel 2
    run linux-gnu-qtfree-completion.log ctest --test-dir /build/qtfree-application --output-on-failure
    run linux-gnu-reference-entry.log python3 -B /source/tools/validation/check_references.py
    python3 -B /source/tools/architecture/capture_build.py --build /build --id linux-gnu --raw /results
    printf 'PASS: clean product build completion, stable inputs and Qt-free client\n'
elif [ "$TASK_ACTION" = test ]; then
    run linux-gnu-test.log ctest --test-dir /build -L normal --output-on-failure --output-junit /results/linux-gnu-tests.xml
    run linux-gnu-capture.log python3 -B /source/tools/architecture/capture_build.py --build /build --id linux-gnu --raw /results
    run linux-gnu-references.log python3 -B /source/tools/validation/check_references.py
    tail -n 9 /results/linux-gnu-test.log
elif [ "$TASK_ACTION" = standalone ]; then
    run linux-gnu-public-headers.log python3 -B /results/public_headers.py
    test ! -f /build/standalone/CMakeCache.txt
    run linux-gnu-standalone-configure.log cmake -S /source/tests -B /build/standalone -G Ninja -DCMAKE_BUILD_TYPE=Release -DQUALPF_BUILD_CONTRACT_TESTS=ON -DQUALPF_BUILD_SEARCH_INTEGRATION_TESTS=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
    run linux-gnu-standalone-build.log cmake --build /build/standalone --parallel 2 --target qualpf_contract_tests qualpf_search_integration_tests
    run linux-gnu-standalone-test.log ctest --test-dir /build/standalone -R '^qualpf\.(contracts|search\.integration)$' --output-on-failure --output-junit /results/linux-gnu-standalone-tests.xml
    cat /results/linux-gnu-public-headers.log
    tail -n 5 /results/linux-gnu-standalone-test.log
elif [ "$TASK_ACTION" = install ]; then
    run linux-gnu-install.log cmake --install /build --prefix /build/install
    run linux-gnu-installed-cli.log python3 -B /source/tests/product/cli/search_boundary.py --executable /build/install/bin/qualpf --source /source --output /results/installed-cli.json
    run linux-gnu-installed-runtime.log python3 -B /results/runtime_smoke.py /build/install portable
    run linux-gnu-zero-fortran.log python3 -B /source/tools/validation/check_zero_fortran.py --build /build --objdump /usr/bin/objdump --nm /usr/bin/nm --output /results/linux-gnu-zero-fortran.json
    tail -n 3 /results/linux-gnu-installed-runtime.log
elif [ "$TASK_ACTION" = package ]; then
    run linux-gnu-deb-configure.log cmake -S /source -B /build -DBUILD_DEB_PACKAGE=ON -DCMAKE_INSTALL_PREFIX=/usr
    run linux-gnu-deb-build.log cmake --build /build --parallel 2
    run linux-gnu-deb-package.log cpack --config /build/CPackConfig.cmake -G DEB -B /build/packages
    run linux-gnu-deb-runtime.log python3 -B /results/deb_install.py
    tail -n 4 /results/linux-gnu-deb-runtime.log
else
    echo "Unsupported action: $TASK_ACTION" >&2
    exit 2
fi
