import hashlib
import json
from pathlib import Path
import shutil
import subprocess

packages = list(Path('/build/packages').glob('*.deb'))
assert len(packages) == 1, packages
package = packages[0]
root = Path('/build/deb-installed')
assert not root.exists()
database = root / 'var/lib/dpkg'
database.mkdir(parents=True)
# The SDK supplies the matching supported system runtime. A private package
# database and installation root keep that previously accepted SDK unchanged.
shutil.copyfile('/var/lib/dpkg/status', database/'status')
command = ['dpkg','--root='+str(root),'--install',str(package)]
completed = subprocess.run(command,capture_output=True,text=True)
Path('/results/deb-install.log').write_text(completed.stdout+completed.stderr)
assert completed.returncode == 0, completed.stdout+completed.stderr
info = subprocess.check_output(['dpkg-deb','--info',str(package)],text=True)
contents = subprocess.check_output(['dpkg-deb','--contents',str(package)],text=True)
assert 'libqt6sql6-sqlite' in info and not any(value in info.lower() for value in ('gfortran','quadmath','ifcore','ifport'))
report = dict(status='PASS',package=str(package),bytes=package.stat().st_size,
              sha256=hashlib.file_digest(package.open('rb'),'sha256').hexdigest(),
              install_command=command,exit_code=completed.returncode,info=info,contents=contents,
              dependency_database='Copied accepted SDK package status; private install root',
              system_runtime='Unmodified accepted SDK /usr/lib providers')
Path('/results/deb-package.json').write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['python3','-B','/source/tests/product/cli/search_boundary.py',
                '--executable',str(root/'usr/bin/qualpf'),'--source','/source',
                '--output','/results/deb-installed-cli.json'],check=True)
subprocess.run(['python3','-B','/results/runtime_smoke.py',str(root/'usr'),'deb'],check=True)
print('PASS: supported DEB generation and private-root dpkg installation; dependency checks enabled')
