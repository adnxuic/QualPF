import json
from pathlib import Path
import shlex
import subprocess

commands = json.loads(Path('/build/qtfree-application/compile_commands.json').read_bytes())
consumer = next(row for row in commands if row['file'].endswith('/application_boundary.cpp'))
tokens = shlex.split(consumer['command'])
flags = []
i = 1
while i < len(tokens):
    if tokens[i] == '-o':
        i += 2
        continue
    if tokens[i] not in ('-c', consumer['file']):
        flags.append(tokens[i])
    i += 1
assert not any('Qt' in token or 'QT_' in token for token in flags)
result = dict(status='PASS', consumer_flags=flags, headers=[])
for base in (Path('/source/src/application/include'), Path('/source/src/core/include')):
    for header in sorted(base.rglob('*.h')):
        include = header.relative_to(base).as_posix()
        completed = subprocess.run([tokens[0], *flags, '-fsyntax-only', '-x', 'c++', '-'],
                                   input=f'#include "{include}"\n', text=True,
                                   cwd=consumer['directory'], capture_output=True)
        result['headers'].append(dict(header=include, exit_code=completed.returncode,
                                      stdout=completed.stdout, stderr=completed.stderr))
        if completed.returncode:
            result['status'] = 'FAIL'
Path('/results/public-headers.json').write_text(json.dumps(result, indent=2)+'\n')
print(result['status'], len(result['headers']), 'public headers compiled independently with Qt-free consumer flags')
raise SystemExit(result['status'] != 'PASS')
