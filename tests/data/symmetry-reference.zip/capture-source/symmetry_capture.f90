! Test-only observation of retained production symmetry loader and lookup.
! No chemical/native workspace initialization; no replacement algorithms.
subroutine phase14_capture() bind(C)
  use spginfom
  use errormod
  implicit none
  type(spaceg_type) :: group
  type(error_type) :: err
  character(len=1024) :: path, query
  character(len=1) :: mode
  logical :: found
  integer :: number, setting, i, j, status, qid
  read(*,'(a)') path
  call spg_set_symmetry_file(trim(path),err)
  call load_spg_database(err)
  write(*,'(a)') 'SYMMETRY14'
  do number=1,230
    call spg_load(group,spgnum=number,sfound=found)
    if (.not.found) stop 14
    write(*,'(a,2(1x,i0))') 'DEFAULT',number,group%id
    setting=1
    do
      call spg_load(group,spgnum=number,code=setting,sfound=found)
      if (.not.found) exit
      write(*,'(a,9(1x,i0))') 'GROUP',group%id,number,setting,group%standard_id-1, &
        group%nsymop,group%nsymop_prim,group%ncoper,group%symcent,group%id_setting()
      write(*,'(a)') trim(group%symbol_xhm)
      write(*,'(a)') trim(adjustl(group%symbol_hall))
      write(*,'(a)') trim(group%choice)
      write(*,'(a)') trim(group%symbol_alt(1))
      write(*,'(a)') trim(group%symbol_alt(2))
      write(*,'(a)') trim(group%symbol_sch)
      write(*,'(a)') trim(group%pmat)
      write(*,'(a)') trim(group%pmat1)
      do i=1,group%nsymop
        write(*,'(a,10(1x,i0),3(1x,es25.17e3))') 'OP',i, &
          (group%symop(i)%rot(j,:),j=1,3),group%symop(i)%trn
      enddo
      setting=setting+1
    enddo
  enddo
  qid=0
  do
    read(*,'(a)',iostat=status) query
    if(status/=0) exit
    qid=qid+1
    mode=query(1:1)
    if(mode=='N') then
      read(query(3:),*) number,setting
      call spg_load(group,spgnum=number,code=setting,sfound=found)
    elseif(mode=='B') then
      call spg_load(group,spgstr=trim(query(3:)),sfound=found)
    else
      call spg_load(group,spgstr=trim(query(3:)),sopt=mode,sfound=found)
    endif
    i=-1
    if(found) i=group%id
    write(*,'(a,2(1x,i0))') 'LOOKUP',qid,i
  enddo
end subroutine
