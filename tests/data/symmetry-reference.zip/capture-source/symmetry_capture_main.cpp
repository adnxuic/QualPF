extern "C" void phase14_capture();
int main() { phase14_capture(); }
