# Phase 15 audit and pre-implementation contract

The frozen inputs and native capture precede all reflection core edits. Earlier
evidence, all Legacy sources, resource files and the core baseline are hashed in
`prior-evidence-hashes.json`. Existing phase qualifications do not authorize any
Phase 15 classification or enumeration differences.

## Observed production path

`databasebuilder.cpp -> libfor.cpp::readCrystalInfoFromCif -> import_data_structure
::get_crystal_info_from_cif -> gen_form import -> exportqualx
::intensity_file_for_database -> crystal_phase_t%make_reflections ->
reflection_type_util::create_reflections` owns the reflection list together with
occupancy/ADP corrections, structure factors, Lorentz/polarization, overlap
intensities and RIR. `sphase` owns both `ref` and `refc`; its tth overload calculates
angles again. Its d overload supplies negative wavelength, which the generic d
entry negates again, enabling angle sorting. `gen_form::import_crystal_dir` also
generates reflections for imported structures. `chem_files` structure comparison
uses generation then `fcalcang`. Scattering normalization calls
`calcola_mult_new` inside `reflectionsutil`. These consumers stay entirely Legacy.
No C++/Fortran list mirror, scattering calculation or profile switch is added.

## Native mathematics to freeze

`get_symm_from_spg` copies the direct fractional column rotation R unchanged.
`geneq`, `extin` and `calcola_mult_new` evaluate the integer ROW product hR;
equivalently the column index transforms by transpose(R). Translation does not
participate in equivalence; it contributes h dot t to the phase when hR=h.
The per-operation IMAGE transcript distinguishes transpose errors even when the
full group orbit coincides under inverse. A non-diagonal trigonal screw setting
is a required explicit witness.

Legacy powder multiplicity identifies hR up to sign, then doubles the number of
unique pairs, including acentric groups. Its single-crystal experiment flag is
not a suitable definition of the symmetry-only orbit. The new API must expose
separate symmetry-only and Friedel-merged policies. Inversion in a centrosymmetric
group is already in the symmetry orbit. Powder generation explicitly selects
merged Friedel pairs.

`geneq` maximizes `131328+abs(262144*h+512*k+l)` and decodes it via `unpack2`.
Within the ordinary index range this is lexicographic maximum of the sign-merged
orbit. Packed arithmetic is not a safe general index representation. All signed
index comparisons in the new domain are component-wise integer comparisons.

Legacy enumeration scans fixed bounds 100 with crystal-system-specific sectors,
excludes 000, tests inclusive rho squared bounds, then canonicalizes and deduplicates
using `abs(h*40401+k*201+l+20200)`. Its maximum list length is 50000. `geneq` mutates
the temporary upper limit; a duplicate skips restoration. The d generic negates
wavelength and normally leaves angles uninitialized and order unsorted. The
capture calculates those fields separately without sorting. Positive-wave angle
entry sorts by NR `indexx`, whose equal-angle ordering is not stable.

`extin` first applies the P/A/B/C/I/F/R integer centering table, then checks
nonzero translations on stabilizing operations. It decides integrality with
`mod(int((abs(h dot t)+0.0005)*1000),1000)`, using binary32 translations.
The new definition uses all exact denominator-12 operations: a stabilizer with
nonzero integer phase modulo 12 proves systematic absence. No floating tolerance
is permitted in hkl, phase, orbit, canonical or multiplicity comparisons.

## New enumeration and errors

Use only Phase 13 UnitCell methods for d and Bragg conversions. Closed d and angle
intervals have binary64 endpoint semantics, with no expanded inclusion tolerance.
Bound each index by direct-cell length divided by the effective minimum d
(Cauchy-Schwarz); conservatively round the scan bound upwards. A caller-specified
candidate budget prevents impractically large scans and returns an error, never
a silently truncated ReflectionSet. Reject incompatible cell/group metrics before
deduplicating equivalents. Sort by increasing binary64 2theta, then lexicographic
hkl to resolve exact ties. Freeze and report native ordering differences separately
from membership; approval is required for acceptance of each differing case.

Invalid nonfinite/nonpositive wavelengths or d limits, reversed intervals, invalid
angle endpoints, zero reflection class, transformed-index overflow, incompatible
cell/group and exceeded candidate budget produce stable Result errors. The core
has no mutable globals, Qt, Fortran runtime, resource I/O or intensity fields.

## Comparison

Native integer fields and ordered membership: exact. d relative 2e-5, absolute 0;
2theta absolute 1e-4 degree plus relative 2e-6, inherited from Phase 13 normal
geometry. Never widen these tolerances after observing output. All raw ordering,
boundary or classification failures remain in machine-readable results. Any
acceptance requires a named case record, independent proof and explicit user
approval. Invalid 000's native placeholder observations are preserved, while the
new API rejects it under Phase 13's existing zero-hkl contract.
