extern "C" void phase15_capture();
int main() { phase15_capture(); }
