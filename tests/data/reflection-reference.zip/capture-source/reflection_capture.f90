! Test-only adapter: every observation calls retained production mathematics.
subroutine phase15_capture() bind(C)
  use spginfom
  use errormod
  use unit_cell, only: matrice_mreciproca
  use reflection_type_util
  implicit none
  type(spaceg_type) :: group
  type(error_type) :: err
  type(reflection_type) :: probe(1)
  type(reflection_type), allocatable :: refs(:)
  character(len=1024) :: path
  integer :: cid, number, setting, np, ne, status, i, j, q, mode, nref
  integer :: nsym, icent, jsys, latt, ksym, jex, m, h(3), canon(3), image(3)
  integer :: vsym(192), ihmx(3), idelt, jcode, isnn, istd, mx(3)
  integer, allocatable :: kmat(:,:,:)
  real, allocatable :: tmat(:,:)
  real :: cell(6), wave, eps, rho, rhomax, pp(6), matr(3,3), low, high
  logical :: found
  integer, parameter :: ibrav(6,13)=reshape([ &
    1,1,1,1,3,1, 0,1,1,1,0,-1, 1,0,1,1,1,1, 1,1,0,1,1,1, &
    2,2,2,2,2,3, 0,0,0,0,1,0, 0,0,0,0,0,0, 0,0,0,0,1,0, &
    0,0,0,0,2,0, 0,0,0,0,1,0, 0,0,0,0,1,0, 0,0,0,0,0,0, &
    0,0,0,0,2,0],[6,13])
  read(*,'(a)') path
  call spg_set_symmetry_file(trim(path),err)
  call load_spg_database(err)
  write(*,'(a)') 'REFLECTION15'
  do
    read(*,*,iostat=status) cid,number,setting,np,ne
    if(status/=0) exit
    read(*,*) cell,wave
    call spg_load(group,spgnum=number,code=setting,sfound=found)
    if(.not.found) stop 15
    allocate(kmat(group%nsymop,3,3),tmat(group%nsymop,3))
    call get_symm_from_spg(group,cell,kmat,tmat,jsys,latt,nsym,icent)
    matr=matrice_mreciproca(cell)
    pp=[.25*matr(1,1),.25*matr(2,2),.25*matr(3,3),.5*matr(1,2),.5*matr(1,3),.5*matr(2,3)]
    ksym=0
    do i=2,nsym
      if(any(abs(tmat(i,:))>0.00001)) then
        ksym=ksym+1
        vsym(ksym)=i
      endif
    enddo
    write(*,'(a,7(1x,i0))') 'CASE',cid,group%id,nsym,icent,jsys,latt,group%nsymop
    do q=1,np
      read(*,*) h
      call extin(jex,h(1),h(2),h(3),ibrav,latt-1,ksym,vsym,nsym,kmat,tmat,icent)
      canon=h; ihmx=0; mx=0; rhomax=1.0e20
      call geneq(0,canon(1),canon(2),canon(3),idelt,jcode,isnn,istd,rho, &
        kmat,tmat,icent,nsym,rhomax,ihmx,pp,mx(1),mx(2),mx(3))
      call calcola_mult_new(h,nsym,icent,eps,m,kmat,POWDER_EXP)
      probe(1)%hkl=h
      if(any(h/=0)) then
        call calculate_2theta(probe,cell,[wave])
        write(*,'(a,9(1x,i0),2(1x,es25.17e3))') 'PROBE',q,h,jex,canon,m,probe(1)%dval(),probe(1)%tthd(1)
      else
        write(*,'(a,9(1x,i0),2(1x,es25.17e3))') 'PROBE',q,h,jex,canon,m,0.0,0.0
      endif
      do j=1,group%nsymop
        image=matmul(h,kmat(j,:,:))
        write(*,'(a,4(1x,i0))') 'IMAGE',j,image
      enddo
    enddo
    do q=1,ne
      read(*,*) mode,low,high
      if(mode==0) then
        ! Positive input deliberately retains unsorted d-entry behavior.
        call create_reflections(low,cell,group,[wave],refs,nref,ihmx)
        ! Populate otherwise undefined d/angle fields without changing order.
        if(nref>0) call calculate_2theta(refs,cell,[wave])
      else
        call create_reflections(low,high,cell,group,[wave],refs,nref,ihmx)
      endif
      write(*,'(a,2(1x,i0))') 'ENUM',q,nref
      do j=1,nref
        write(*,'(a,5(1x,i0),2(1x,es25.17e3))') 'REF',j,refs(j)%hkl,refs(j)%m,refs(j)%dval(),refs(j)%tthd(1)
      enddo
    enddo
    deallocate(kmat,tmat)
  enddo
end subroutine
