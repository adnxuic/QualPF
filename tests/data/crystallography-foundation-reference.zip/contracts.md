# Phase 13 contract — frozen before production implementation

Baseline `0e53b6cb1d080d2e1a6741c6f87a81f968937a06`. The new foundation uses
binary64, explicit Å / Å⁻¹ lengths and degree angles, no 2π in reciprocal vectors.
It has no state, table loading, symmetry normalization or implicit wavelength.

Capture calls retained `cell_type%set/get_g/get_r/volume`, `cella_reciproca`,
`cell_volume`, `calculate_2theta`, `reflection_type%dval`, `counts::thvalue/dvalue`.
Reciprocal parameters in Legacy contain cosines, not angles. Capture preserves
these raw outputs. Reciprocal-back angles are likewise cosines. No reflection
enumeration or structure factor is executed by this explicit-hkl harness.

Before C++ implementation the normal comparison tolerances are:

* metric components normalized by the input lengths' outer product: absolute
  2e-6, relative 2e-5; reciprocal metric normalized by reciprocal lengths' outer
  product: same. This retains a scale-aware absolute bound for right-angle
  binary32 cosine residue; no unscaled absolute bound for huge cells.
* volume, reciprocal volume, reciprocal lengths, reciprocal-back lengths,
  reciprocal-vector norm and d: relative 2e-5, absolute zero.
* reciprocal/back cosine: absolute 2e-6, relative 2e-5.
* 2θ: absolute 1e-4 degree, relative 2e-6; Bragg-back d: relative 2e-5.
* explicitly named 1° / 179° limiting-angle cases use relative 1e-3 for the
  scalar/normalized-metric fields (binary32 cancellation amplified by angular
  conditioning); angle absolute 0.01 degree, relative 1e-3. They also require
  independent binary64 inverse/roundtrip property checks. No tolerance changes
  are permitted after observing C++ output.

All expected numbers must come from Fortran transcripts; nonfinite outputs,
unphysical finite outputs, negative-wavelength angles, `-999` sentinels and
reflection asin clamping are historical evidence, never valid golden values.

The factory rejects nonfinite/nonpositive lengths; nonfinite angles or angles
outside (0,180); geometrically impossible angle triples (triangle inequalities
and sum <360); normalized metric determinant <=64*double epsilon; and any
nonrepresentable positive volume, reciprocal volume or metric diagonal.
This determinant guard measures angular degeneracy, not aspect ratio. Zero hkl
is rejected for reflection norm and d. All int32 nonzero indices are accepted
when results remain finite and positive. No integer squaring is used.

Bragg requires positive finite wavelength/d and 0<2θ<=180. Asin ratios >1 are
rejected without epsilon clamping; tiny underflowed/nonfinite results fail.
Structured Result errors carry stable reasons. Invalid input never constructs
a valid cell or returns a fake finite reflection. Normalized metric factories
and reciprocal conversions may reject geometry too ill-conditioned to represent
reliably; that is explicit, not an uninitialized result.

Existing binary32 Pattern IO/preprocessing/Search/Kα2 behavior is untouched.
No production consumer is switched until its foundation-only boundary can be
separated from the retained symmetry/CIF/Profile pipelines.
