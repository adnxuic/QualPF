! No initialization/tables and no C++ arithmetic: call actual retained routines.
subroutine phase13_capture() bind(C)
  use unit_cell
  use reflection_type_util, only: reflection_type, calculate_2theta
  use counts, only: thvalue, dvalue
  implicit none
  real :: p(6), wave, rec(6), recpar(6), back(6), g(3,3), r(3,3), d, t
  integer :: hkl(3), i
  type(cell_type) :: cell
  type(reflection_type) :: ref(1)
  read(*,*) p
  read(*,*) hkl
  read(*,*) wave
  call cell%set(p)
  g=cell%get_g(); r=cell%get_r()
  rec=cella_reciproca(p)
  recpar(:3)=rec(:3)
  recpar(4:6)=acos(rec(4:6))*rtod
  back=cella_reciproca(recpar)
  ref(1)%hkl=hkl
  call calculate_2theta(ref,p,[wave])
  d=ref(1)%dval()
  t=thvalue(d,wave)
  write(*,'(a)') 'FOUNDATION13'
  write(*,'(a,9(1x,es25.17e3))') 'metric', (g(i,:),i=1,3)
  write(*,'(a,9(1x,es25.17e3))') 'reciprocal_metric', (r(i,:),i=1,3)
  write(*,'(a,6(1x,es25.17e3))') 'reciprocal', rec
  write(*,'(a,6(1x,es25.17e3))') 'back', back
  write(*,'(a,1x,es25.17e3)') 'volume', cell%volume()
  write(*,'(a,1x,es25.17e3)') 'reciprocal_volume', cell_volume(recpar)
  write(*,'(a,1x,es25.17e3)') 'norm', 2*sqrt(ref(1)%slaq)
  write(*,'(a,1x,es25.17e3)') 'd', d
  write(*,'(a,1x,es25.17e3)') 'reflection_two_theta', ref(1)%tthd(1)
  write(*,'(a,1x,es25.17e3)') 'counts_two_theta', t
  write(*,'(a,1x,es25.17e3)') 'counts_d', dvalue(t,wave)
end subroutine
