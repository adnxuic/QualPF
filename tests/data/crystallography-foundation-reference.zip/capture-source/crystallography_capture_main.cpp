extern "C" void phase13_capture();
int main() { phase13_capture(); }
