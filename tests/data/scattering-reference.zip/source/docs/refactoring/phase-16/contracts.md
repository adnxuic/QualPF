# Phase 16 pre-implementation contract

This contract and the native corpus are established before any production C++
scattering implementation. Previous phase evidence is immutable; its hashes are
in `prior-evidence-hashes.json`. No previous qualification applies here.

## Observed call graph

`databasebuilder -> libfor::readCrystalInfoFromCif -> import_data_structure ->
gen_form/cif_form -> exportqualx::intensity_file_for_database -> sphase ->
reflectionsutil::fcalcang -> sfcalc[_anis]` owns CIF interpretation, atoms,
reflections, occupancy, scattering, LP, overlap, density and RIR together.
`gen_form::make_powder_pattern_var` and structure comparison in `chem_files`
also retain these calculations. There is no independent state-free F boundary.
Phase 16 makes zero production consumer switches.

## Source conventions

* `reflection%slaq` and `at_scatt` receive s squared, s=sin(theta)/lambda=1/(2d).
  X-ray uses four Gaussian pairs and a constant from AtomProperties.xen.
  The loader uses the default REAL `Getnum` parser. Labels are case insensitive;
  the strict species lookup does not invent ionic coefficients or alias charges.
* Neutron scattering is the resource's signed constant (units 10^-12 cm).
  Electron scattering uses the active Lobato table, neutral Z even for ions,
  sum a_i (2+b_i s²)/(1+b_i s²)². The Fortran table's unsuffixed literals first
  round to default REAL despite their destination being DP. Z>103 returns zero.
* NIST supports Z=1..92. Energy uses the source h=6.62607015e-34,
  c=2.998e8, e=1.602176634e-19 and keV-Angstrom factor 1e7*h*c/e.
  fprime is linear interpolation of f1 minus Z plus frel; fdoubleprime is
  log-log interpolation. Outside the table returns zero with error; unsupported
  Z returns zero without error. The C++ API must report unsupported explicitly.
* Phase is exp(+2*pi*i*h dot x). Anomalous amplitude is f0+fprime+i*fdoubleprime.
  Legacy stores magnitude Fc and an integer rounded degree phase, not complex F.
  Test-only extraction of the unchanged four retained routines adds WRITE-only
  diagnostics; its Fc/phase must exactly match execution of the original entry.
* Chemical occupancy och multiplies ocry. `calcola_occ_new` counts unique
  symmetry equivalents with metric distance <=0.3 Angstrom in the CIF workflow,
  then ocry=unique/all operations. This is a proximity heuristic, not a Wyckoff
  or exact-position calculation. The C++ contract uses fractional modulo-lattice
  coincidence tolerance 1e-10. It never merges distinct ASU sites.
* Isotropic attenuation exp(-B*s²), B=8*pi²*U. Anisotropic tensor order is
  11,22,33,12,13,23. Legacy `bij` is dimensionless beta, NOT crystallographic B.
  beta_ij=2*pi²*a_i_star*a_j_star*U_ij; attenuation exp(-hR beta (hR)^T).
  Crystallographic B_ij=8*pi² U_ij. These tensors are not Cartesian U tensors.
  `get_g` is the direct metric, used for occupation distances and Bequiv.
* No multiplicity, LP, scale, overlap or RIR is part of Fc squared.

## Historical observations requiring explicit treatment

The anisotropic acentric anomalous branch omits fprime, even for isotropic
sites. Anomalous scattering defaults false in `general`; the selectable branch
is still captured. Centering multiplies ncoper assuming an allowed reflection;
explicit extinct centering indices can therefore produce spurious nonzero Fc.
The anisotropic branch selects beta only when beta11>0. The old validity check
tests only the determinant, insufficient to establish positive definiteness.
`elem_set_scatt_s` restores X-ray cl from itself rather than cx after a radiation
switch; captures must distinguish fresh entries from stale mutable state.
Invalid historical outputs remain observations, not definitions of valid C++
results. Scientific differences require case-specific evidence and approval.

## Frozen comparison rules

Normal finite scattering: absolute 2e-5 plus relative 3e-6. Anomalous fprime and
fdoubleprime: absolute 3e-5 plus relative 5e-6 away from absorption edges.
Structure F components and magnitude: absolute 2e-4 plus relative 2e-5;
Fc squared: absolute 0.02 plus relative 6e-5. These account for default REAL
tables, elementary functions and serial summation. Integer Legacy phases use
the independently computed nearest degree, except undefined near-zero phases.
ADP conversion: absolute 2e-7 plus relative 3e-6. Occupancy counts are exact.
Boundary and invalid observations are separately named, never silently dropped.
These tolerances are fixed before observing any new C++ output. Failures remain
in machine-readable comparisons; qualification does not rewrite the reference
or increase tolerance. MinGW and MSVC must both be recorded.

## C++ contract

Binary64 arithmetic, immutable validated structure and species values, Qt-free
and Fortran-free public API. Coordinates are finite and wrapped to [0,1).
Occupancy is in [0,1]. Isotropic and anisotropic displacement are nonnegative
(positive semidefinite tensors accepted, including zero). Symmetry expansion
transforms the tensor as well as the coordinate; incompatible tensors on a
special-position stabilizer return a structured error rather than silently
averaging inconsistent physical sites. Deterministic canonical atom ordering
and compensated summation make results independent of input site order.
Geometry comes from Phase 13/15. Reflection d, angle and wavelength are checked
against the owning structure; group/cell compatibility is validated. Errors
have stable field and reason strings, with no NaN, sentinel or partial result.
