module qualx_main
   use iso_c_binding

   implicit none

   type, bind(C) :: param_options_type
        integer(c_int) :: nogui = 0
        integer(c_int) :: auto = 0
        integer(c_int) :: indexing = 0
        real(c_float)  :: wavel = 0.0
   end type param_options_type

contains

   ! Runtime/table initialization only. Pattern files are owned/read by C++.
   subroutine initialize_native_workspace(param_opt,exepathcc,len_path,ier) bind(C)
   use general, only: ifAutomatic
   use molcom, only: jscreen
   use strutil
   use gen_frm
   use errormod
   type(param_options_type) :: param_opt
   character(c_char), intent(in) :: exepathcc(*)
   integer(c_int), value :: len_path
   integer(c_int), intent(out) :: ier
   type(error_type) :: err
   call init_qualx()
   ifAutomatic = param_opt%auto
   if (param_opt%nogui == 1) jscreen = 0
   call load_chemical_tables(toFortranString(exepathcc,len_path),err)
   ier = 0
   if (err%signal) ier = 1
   end subroutine initialize_native_workspace

   subroutine init_qualx()
   use crystal_phase, only: new_phases, clear_phases
   use datasetmod, only: clear_dataset
   use variables, only: cryst, dataset
   use molcom, only: jscreen
!
   jscreen = 1
   call clear_dataset(dataset)
!
   call clear_phases(cryst)
   call new_phases(cryst,1)

   end subroutine init_qualx

!-------------------------------------------------------------------------------

   subroutine init_qualx_tables(exepathcc, len_path, ier) bind(C, name="init_qualx_tables")
   use iso_c_binding
   use strutil,   only: toFortranString
   use errormod
   use gen_frm
   character(c_char), intent(in) :: exepathcc(*)
   integer(c_int), value         :: len_path
   integer(c_int), intent(out)   :: ier
   character(len=:), allocatable :: exepath
   type(error_type)              :: err

   exepath = toFortranString(exepathcc, len_path)
   call load_chemical_tables(exepath, err)
   if (err%signal) then
       ier = 1
   else
       ier = 0
   endif

   end subroutine init_qualx_tables

end module qualx_main
