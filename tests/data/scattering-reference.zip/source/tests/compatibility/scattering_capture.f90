! Test-only adapter to retained production functions. Input protocol is frozen.
subroutine phase16_capture() bind(C)
  use elements
  use nist_mod
  use spginfom
  use errormod
  use atom_basic
  use atom_type_util, only: calcola_occ_new
  use unit_cell, only: matrice_metrica, matrice_mreciproca, cella_reciproca
  use ccryst, only: beta_from_uij, u_from_bij, b_from_bij, bequiv_from_beta, b_from_u
  use reflection_type_util
  use phase16_trace
  implicit none
  type(element_type) :: entry
  type(element_type), allocatable :: elem(:)
  type(atom_type), allocatable :: atoms(:)
  type(reflection_type) :: refs(1), traced(1)
  type(spaceg_type) :: group
  type(error_type) :: err
  character(len=1024) :: path
  character(len=20) :: mode, label
  integer :: status, cid, p, i, j, rad, z, number, setting, na, nr, anom, anis, adp
  real :: s2, wave, f1, f2, mu, cell(6), tensor(6), beta(6), rc(6), gr(3,3), gg(3,3)
  logical :: found
  read(*,'(a)') path
  call read_chemical_elements(trim(path),err)
  if(err%signal) stop 16
  read(*,'(a)') path
  call spg_set_symmetry_file(trim(path),err)
  call load_spg_database(err)
  write(*,'(a,1x,i0)') 'SCATTERING16',N_ELEMENTS
  do i=1,N_ELEMENTS
    write(*,'(a,1x,i0,1x,a,2(1x,i0),10(1x,es25.17e3))') &
      'TABLE',i,trim(eleminfo(i)%lab),eleminfo(i)%z,eleminfo(i)%charge, &
      eleminfo(i)%ax,eleminfo(i)%bx,eleminfo(i)%cx,eleminfo(i)%fact
  enddo
  do
    read(*,*,iostat=status) mode,cid
    if(status/=0) exit
    select case(trim(mode))
    case('SCAT')
      read(*,*) label,rad,s2
      p=pxen_from_specie(trim(label))
      if(p==0) then
        write(*,'(a,1x,i0)') 'UNKNOWN',cid
        cycle
      endif
      entry=eleminfo(p)
      call elem_set_radiation(entry,rad)
      write(*,'(a,3(1x,i0),2(1x,es25.17e3))') 'SCAT',cid,p,rad,s2,at_scatt(entry,s2,rad)
    case('ANOM')
      read(*,*) z,wave
      call get_nist_parameters(z,wave,f1,f2,mu,err)
      write(*,'(a,2(1x,i0),1x,l1,4(1x,es25.17e3))') 'ANOM',cid,z,err%signal,wave,f1,f2,mu
    case('ADP')
      read(*,*) cell
      read(*,*) tensor
      gr=matrice_mreciproca(cell); rc=cella_reciproca(cell); gg=matrice_metrica(cell)
      beta=beta_from_uij(tensor,gr,rc)
      write(*,'(a,1x,i0,19(1x,es25.17e3))') 'ADP',cid,beta,u_from_bij(beta,gr,rc), &
        b_from_bij(beta,gr,rc),bequiv_from_beta(beta,gg)
    case('STRUCT')
      read(*,*) number,setting,na,nr,rad,anom,anis,wave
      read(*,*) cell
      call spg_load(group,spgnum=number,code=setting,sfound=found)
      if(.not.found) stop 17
      allocate(elem(na),atoms(na))
      gr=matrice_mreciproca(cell); rc=cella_reciproca(cell); gg=matrice_metrica(cell)
      do i=1,na
        read(*,*) label,atoms(i)%xc,atoms(i)%och,adp,tensor
        p=pxen_from_specie(trim(label))
        if(p==0) stop 18
        elem(i)=eleminfo(p)
        call elem_set_radiation(elem(i),rad)
        call elem_set_nist_factors(elem(i),wave,rad,err)
        call atoms(i)%set_specie_from_el(i,elem)
        if(adp==0) atoms(i)%biso=tensor(1)
        if(adp==1) atoms(i)%biso=b_from_u(tensor(1))
        if(adp==2) atoms(i)%bij=beta_from_uij(tensor,gr,rc)
        if(adp==3) atoms(i)%bij=tensor
      enddo
      call calcola_occ_new(atoms,group,gg,0.3)
      write(*,'(a,3(1x,i0))') 'STRUCT',cid,group%id,group%nsymop
      do i=1,na
        write(*,'(a,1x,i0,8(1x,es25.17e3))') 'SITE',i,atoms(i)%ocry,atoms(i)%biso,atoms(i)%bij
      enddo
      do j=1,nr
        read(*,*) refs(1)%hkl
        call calculate_2theta(refs,cell,[wave])
        traced=refs
        call fcalcang(refs,atoms,group,elem,rad,anom/=0,anis=anis/=0)
        write(*,'(a,5(1x,i0),4(1x,es25.17e3))') 'FC',j,refs(1)%hkl,refs(1)%ph, &
          refs(1)%slaq,refs(1)%fc,refs(1)%fc**2,refs(1)%tthd(1)
        if(anis==0.and.anom==0) call trace_sfcalc_no_anomal(traced,atoms,group,elem,rad)
        if(anis==0.and.anom/=0) call trace_sfcalc_anomal(traced,atoms,group,elem,rad)
        if(anis/=0.and.anom==0) call trace_sfcalc_anis_no_anomal(traced,atoms,group,elem,rad)
        if(anis/=0.and.anom/=0) call trace_sfcalc_anis_anomal(traced,atoms,group,elem,rad)
        if(traced(1)%fc/=refs(1)%fc.or.traced(1)%ph/=refs(1)%ph) stop 19
      enddo
      deallocate(elem,atoms)
    case default
      stop 20
    end select
  enddo
end subroutine
