extern "C" void phase16_capture();
int main() { phase16_capture(); }
