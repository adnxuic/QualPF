! Generated WRITE-only native observation clone. Do not edit.
module phase16_trace
use reflection_type_util, only: reflection_type
implicit none
contains
   subroutine trace_sfcalc_no_anomal(ref,atx,spg,elem,radtype)
   USE trig_constants
   USE spginfom
   USE elements
   USE atom_basic
!
   type(reflection_type), dimension(:), intent(inout) :: ref    ! i riflessi
   type(atom_type), dimension(:), intent(in)          :: atx    ! modello strutturale
   type(spaceg_type), intent(in)                      :: spg
   type(element_type), dimension(:), intent(in)       :: elem
   integer, intent(in)                                :: radtype
   integer                                            :: natoms
   real, dimension(4,spg%nsym)                        :: hkle
   integer, dimension(3)                              :: i1
   integer                                            :: i,j,jj
   real                                               :: rho
   integer                                            :: kz
   real                                               :: contc
   real                                               :: conts
   real                                               :: tfocc
   real                                               :: freal,fimag
   real                                               :: faze
   real                                               :: at,bt
   real                                               :: argg
   real, dimension(size(elem)) :: ff

   natoms = size(atx)
   if (spg%symcent == 1) then
       loop_riflessi1: do i=1,size(ref)
          i1 = ref(i)%hkl
!--     compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo
          rho=ref(i)%slaq
!      
          ff(:) = at_scatt(elem,rho,radtype)
!      
          freal=0.0
          loop_atomi1: do jj=1,natoms
             kz = atx(jj)%kscatt()
             tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
             at=0.0
             do j=1,spg%nsym
                argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                at = at + cos(argg)
             enddo
             freal=freal+at*tfocc
          enddo loop_atomi1
!      
          freal = 2.0*freal
          if (freal >= 0.0) then
              ref(i)%fc = freal
              ref(i)%ph = 0
          else
              ref(i)%fc = -freal
              ref(i)%ph = 180
          endif
          !write(71,'(4i5,2f10.3,i5)')i,ref(i)%hkl,freal,ref(i)%fc,ref(i)%ph
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,fimag
      enddo loop_riflessi1
   else
      loop_riflessi: do i=1,size(ref)
         i1 = ref(i)%hkl
         do j=1,spg%nsym
            hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
            hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
         enddo
         rho=ref(i)%slaq
!     
         ff(:) = at_scatt(elem,rho,radtype)
!     
         freal=0.0
         fimag=0.0
         loop_atomi: do jj=1,natoms
            kz = atx(jj)%kscatt()
            tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
            at=0.0
            bt=0.0
            do j=1,spg%nsym
               argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
               at = at + cos(argg)
               bt = bt + sin(argg)
            enddo
            contc=at
            conts=bt
            freal=freal+contc*tfocc
            fimag=fimag+conts*tfocc
         enddo loop_atomi
!     
         ref(i)%fc = sqrt(freal**2+fimag**2)
         faze=rtod*atan2(fimag,freal)+360.0
         ref(i)%ph = mod(int(faze+0.5),360)
         !write(71,'(4i5,3f10.3,i5)')i,ref(i)%hkl,freal,fimag,ref(i)%fc,ref(i)%ph
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,0.0
      enddo loop_riflessi
   endif
!
   end subroutine trace_sfcalc_no_anomal
   subroutine trace_sfcalc_anomal(ref,atx,spg,elem,radtype)
   USE trig_constants
   USE spginfom
   USE elements
   USE atom_basic
!
   type(reflection_type), dimension(:), intent(inout) :: ref    ! i riflessi
   type(atom_type), dimension(:), intent(in)          :: atx    ! modello strutturale
   type(spaceg_type), intent(in)                      :: spg
   type(element_type), dimension(:), intent(in)       :: elem
   integer, intent(in)                                :: radtype
   integer                                            :: natoms
   real, dimension(4,spg%nsym)                        :: hkle
   integer, dimension(3)                              :: i1
   integer                                            :: i,j,jj
   real                                               :: rho
   integer                                            :: kz
   real                                               :: tconst,tfocc,tfoccd
   real                                               :: freal,fimag
   real                                               :: freal1,fimag1,freal2,fimag2
   real                                               :: faze
   real                                               :: at,bt
   real                                               :: argg
   real, dimension(size(elem))                        :: ff

   natoms = size(atx)
   if (spg%symcent == 1) then
       loop_riflessi1: do i=1,size(ref)
          i1 = ref(i)%hkl
!--     compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo
          rho=ref(i)%slaq
!      
          ff(:) = at_scatt(elem,rho,radtype) + elem(:)%f1
!      
          freal=0.0
          fimag=0.0
          loop_atomi1: do jj=1,natoms
             kz = atx(jj)%kscatt()
             tconst=spg%ncoper*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
             tfocc=tconst*ff(kz)
             tfoccd=tconst*elem(kz)%f2
             at=0.0
             do j=1,spg%nsym
                argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                at = at + cos(argg)
             enddo
             freal=freal+at*tfocc
             fimag=fimag+at*tfoccd
          enddo loop_atomi1
!      
          freal = 2*freal
          fimag = 2*fimag
          ref(i)%fc = sqrt(freal**2 + fimag**2)
          faze=rtod*atan2(fimag,freal)+360.0
          ref(i)%ph = mod(int(faze+0.5),360)
!corr          if (freal >= 0.0) then  ! assuming f2 << f0 + f1
!corr              ref(i)%ph = 0
!corr          else
!corr              ref(i)%ph = 180
!corr          endif
          !write(71,'(4i5,3f10.3,2i5)')i,ref(i)%hkl,freal,fimag,ref(i)%fc,ref(i)%ph,ref(i)%m
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,fimag
      enddo loop_riflessi1
   else
      loop_riflessi: do i=1,size(ref)
         i1 = ref(i)%hkl
         do j=1,spg%nsym
            hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
            hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
         enddo
         rho=ref(i)%slaq
!     
         ff(:) = at_scatt(elem,rho,radtype) + elem(:)%f1
!     
         freal1=0.0
         fimag1=0.0
         freal2=0.0
         fimag2=0.0
         loop_atomi: do jj=1,natoms
            kz = atx(jj)%kscatt()
            tconst=spg%ncoper*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
            tfocc=tconst*ff(kz)
            tfoccd=tconst*elem(kz)%f2
            at=0.0
            bt=0.0
            do j=1,spg%nsym
               argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
               at = at + cos(argg)
               bt = bt + sin(argg)
            enddo
!corr            contc=at
!corr            conts=bt
            freal1=freal1+at*tfocc
            freal2=freal2+bt*tfoccd
            fimag1=fimag1+bt*tfocc
            fimag2=fimag2+at*tfoccd
         enddo loop_atomi
!     
         freal = freal1 - freal2
         fimag = fimag1 + fimag2
         ref(i)%fc = sqrt(freal**2+fimag**2)
         faze=rtod*atan2(fimag,freal)+360.0
         ref(i)%ph = mod(int(faze+0.5),360)
         !write(71,'(4i5,3f12.5,2i5)')i,ref(i)%hkl,freal,fimag,ref(i)%fc,ref(i)%ph,ref(i)%m
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,fimag
      enddo loop_riflessi
   endif
!
   end subroutine trace_sfcalc_anomal
   subroutine trace_sfcalc_anis_no_anomal(ref,atx,spg,elem,radtype)
   USE spginfom
   USE trig_constants, only: twopi,rtod
   USE elements
   USE atom_basic
!
   type(reflection_type), dimension(:), intent(inout) :: ref    ! i riflessi
   type(atom_type), dimension(:), intent(in)          :: atx    ! modello strutturale
   type(spaceg_type), intent(in)                      :: spg
   type(element_type), dimension(:), intent(in)       :: elem
   integer, intent(in)                                :: radtype
   integer                                            :: natoms
   real, dimension(4,spg%nsym)                        :: hkle
   integer, dimension(3)                              :: i1
   integer                                            :: i,j,jj
   real                                               :: rho
   integer                                            :: kz
   real                                               :: contc
   real                                               :: conts
   real                                               :: tfocc
   real                                               :: act,bct
   real                                               :: faze
   real                                               :: at,bt
   real                                               :: argg
   real                                               :: anis
   real, dimension(6)                                 :: beta
   real, dimension(3)                                 :: h
   real, dimension(size(elem)) :: ff

   natoms = size(atx)
   if (spg%symcent == 1) then
       loop_riflessi: do i=1,size(ref)
          i1 = ref(i)%hkl
!-- compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo
!
          rho=ref(i)%slaq
!
          ff(:) = at_scatt(elem,rho,radtype)
!
          act=0.0
          loop_atomi: do jj=1,natoms
             kz = atx(jj)%kscatt()
             if (atx(jj)%bij(1) > 0) then
                 tfocc=spg%ncoper*ff(kz)*atx(jj)%och*atx(jj)%ocry
                 at=0.0
                 !bt=0.0
                 beta(:) = atx(jj)%bij(:) ! b11,b22,b33,b12,b13,b23
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    h(:) = hkle(:3,j)
                    anis =    h(1)*h(1)*beta(1)+     h(2)*h(2)*beta(2)+    h(3)*h(3)*beta(3) &
                         +2.0*h(1)*h(2)*beta(4)+ 2.0*h(1)*h(3)*beta(5)+2.0*h(2)*h(3)*beta(6)
                    anis=exp(-anis)
                    at = at + cos(argg)*anis
                 enddo
             else
                 tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 at=0.0
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    at = at + cos(argg)
                 enddo
             endif
             act=act+at*tfocc
          enddo loop_atomi
!
          if (act >= 0.0) then
              ref(i)%fc = 2.0*act
              ref(i)%ph = 0
          else
              ref(i)%fc = -2.0*act
              ref(i)%ph = 180
          endif
          !write(71,'(4i5,3f10.3,i5)')i,ref(i)%hkl,2*act,0.0,ref(i)%fc,ref(i)%ph
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',2.0*act,0.0
       enddo loop_riflessi
   else
        loop_riflessi1: do i=1,size(ref)
          i1 = ref(i)%hkl
!-- compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo

          rho=ref(i)%slaq
!
          ff(:) = at_scatt(elem,rho,radtype)
!
          act=0.0
          bct=0.0
          loop_atomi1: do jj=1,natoms
             kz = atx(jj)%kscatt()
             if (atx(jj)%bij(1) > 0) then
                 tfocc=spg%ncoper*ff(kz)*atx(jj)%och*atx(jj)%ocry
                 at=0.0
                 bt=0.0
                 beta(:) = atx(jj)%bij(:) ! b11,b22,b33,b12,b13,b23
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    h(:) = hkle(:3,j)
                    anis =    h(1)*h(1)*beta(1)+     h(2)*h(2)*beta(2)+    h(3)*h(3)*beta(3) &
                         +2.0*h(1)*h(2)*beta(4)+ 2.0*h(1)*h(3)*beta(5)+2.0*h(2)*h(3)*beta(6)
                    anis=exp(-anis)
                    at = at + cos(argg)*anis
                    bt = bt + sin(argg)*anis
                 enddo
             else
                 tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 at=0.0
                 bt=0.0
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    at = at + cos(argg)
                    bt = bt + sin(argg)
                 enddo
             endif
             contc=at
             conts=bt
             act=act+contc*tfocc
             bct=bct+conts*tfocc
          enddo loop_atomi1
!
          ref(i)%fc = sqrt(act**2+bct**2)
          faze=rtod*atan2(bct,act)+360.0
          ref(i)%ph = mod(int(faze+0.5),360)
          !write(71,'(4i5,3f10.3,i5)')i,ref(i)%hkl,act,bct,ref(i)%fc,ref(i)%ph
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',act,bct
       enddo loop_riflessi1
   endif
!
   end subroutine trace_sfcalc_anis_no_anomal
   subroutine trace_sfcalc_anis_anomal(ref,atx,spg,elem,radtype)
   USE spginfom
   USE trig_constants, only: twopi,rtod
   USE elements
   USE atom_basic
!
   type(reflection_type), dimension(:), intent(inout) :: ref    ! i riflessi
   type(atom_type), dimension(:), intent(in)          :: atx    ! modello strutturale
   type(spaceg_type), intent(in)                      :: spg
   type(element_type), dimension(:), intent(in)       :: elem
   integer, intent(in)                                :: radtype
   integer                                            :: natoms
   real, dimension(4,spg%nsym)                        :: hkle
   integer, dimension(3)                              :: i1
   integer                                            :: i,j,jj
   real                                               :: rho
   integer                                            :: kz
   real                                               :: tconst,tfocc,tfoccd
   real                                               :: freal,fimag
   real                                               :: freal1,fimag1,freal2,fimag2
   real                                               :: faze
   real                                               :: at,bt
   real                                               :: argg
   real                                               :: anis
   real, dimension(6)                                 :: beta
   real, dimension(3)                                 :: h
   real, dimension(size(elem)) :: ff

   natoms = size(atx)
   if (spg%symcent == 1) then
       loop_riflessi: do i=1,size(ref)
          i1 = ref(i)%hkl
!-- compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo
!
          rho=ref(i)%slaq
!
          ff(:) = at_scatt(elem,rho,radtype) + elem(:)%f1
!
          freal=0.0
          fimag=0.0
          loop_atomi: do jj=1,natoms
             kz = atx(jj)%kscatt()
             if (atx(jj)%bij(1) > 0) then
                 !tfocc=spg%ncoper*ff(kz)*atx(jj)%och*atx(jj)%ocry
                 tconst=spg%ncoper*atx(jj)%och*atx(jj)%ocry
                 tfocc=tconst*ff(kz)
                 tfoccd=tconst*elem(kz)%f2
                 at=0.0
                 beta(:) = atx(jj)%bij(:) ! b11,b22,b33,b12,b13,b23
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    h(:) = hkle(:3,j)
                    anis =    h(1)*h(1)*beta(1)+     h(2)*h(2)*beta(2)+    h(3)*h(3)*beta(3) &
                         +2.0*h(1)*h(2)*beta(4)+ 2.0*h(1)*h(3)*beta(5)+2.0*h(2)*h(3)*beta(6)
                    anis=exp(-anis)
                    at = at + cos(argg)*anis
                 enddo
             else
!!!!                 tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 tconst=spg%ncoper*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 tfocc=tconst*ff(kz)
                 tfoccd=tconst*elem(kz)%f2
                 at=0.0
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    at = at + cos(argg)
                 enddo
             endif
!!!!             act=act+at*tfocc
             freal=freal+at*tfocc
             fimag=fimag+at*tfoccd
             write(70,*)'REF:',i,jj,freal,fimag,tfocc,tfoccd
          enddo loop_atomi
!
!!!!          if (act >= 0.0) then
!!!!              ref(i)%fc = 2.0*act
!!!!              ref(i)%ph = 0
!!!!          else
!!!!              ref(i)%fc = -2.0*act
!!!!              ref(i)%ph = 180
!!!!          endif

          freal = 2*freal
          fimag = 2*fimag
          ref(i)%fc = sqrt(freal**2 + fimag**2)
          faze=rtod*atan2(fimag,freal)+360.0
          ref(i)%ph = mod(int(faze+0.5),360)
          !write(71,'(4i5,3f12.5,2i5)')i,ref(i)%hkl,freal,fimag,ref(i)%fc,ref(i)%ph,ref(i)%m
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,fimag
       enddo loop_riflessi
   else
        loop_riflessi1: do i=1,size(ref)
          i1 = ref(i)%hkl
!-- compute H*R and H*T
          do j=1,spg%nsym
             hkle(4,j) = dot_product(i1,spg%symop(j)%trn(:)) ! H*T
             hkle(:3,j) = matmul(i1,spg%symop(j)%rot(:,:))   ! H*R
          enddo

          rho=ref(i)%slaq
!
          ff(:) = at_scatt(elem,rho,radtype)
!
!!!!          act=0.0
!!!!          bct=0.0
          freal1=0.0
          fimag1=0.0
          freal2=0.0
          fimag2=0.0
          loop_atomi1: do jj=1,natoms
             kz = atx(jj)%kscatt()
             if (atx(jj)%bij(1) > 0) then
!!!!                 tfocc=spg%ncoper*ff(kz)*atx(jj)%och*atx(jj)%ocry
                 tconst=spg%ncoper*atx(jj)%och*atx(jj)%ocry
                 tfocc=tconst*ff(kz)
                 tfoccd=tconst*elem(kz)%f2
                 at=0.0
                 bt=0.0
                 beta(:) = atx(jj)%bij(:) ! b11,b22,b33,b12,b13,b23
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    h(:) = hkle(:3,j)
                    anis =    h(1)*h(1)*beta(1)+     h(2)*h(2)*beta(2)+    h(3)*h(3)*beta(3) &
                         +2.0*h(1)*h(2)*beta(4)+ 2.0*h(1)*h(3)*beta(5)+2.0*h(2)*h(3)*beta(6)
                    anis=exp(-anis)
                    at = at + cos(argg)*anis
                    bt = bt + sin(argg)*anis
                 enddo
             else
!!!!                 tfocc=spg%ncoper*ff(kz)*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 tconst=spg%ncoper*exp(-atx(jj)%biso*rho)*atx(jj)%och*atx(jj)%ocry
                 tfocc=tconst*ff(kz)
                 tfoccd=tconst*elem(kz)%f2
                 at=0.0
                 bt=0.0
                 do j=1,spg%nsym
                    argg = twopi*(dot_product(hkle(:3,j),atx(jj)%xc) + hkle(4,j))
                    at = at + cos(argg)
                    bt = bt + sin(argg)
                 enddo
             endif
!!!!             contc=at
!!!!             conts=bt
!!!!             act=act+contc*tfocc
!!!!             bct=bct+conts*tfocc
             freal1=freal1+at*tfocc
             freal2=freal2+bt*tfoccd
             fimag1=fimag1+bt*tfocc
             fimag2=fimag2+at*tfoccd
          enddo loop_atomi1
!
!!!!          ref(i)%fc = sqrt(act**2+bct**2)
!!!!          faze=rtod*atan2(bct,act)+360.0
!!!!          ref(i)%ph = mod(int(faze+0.5),360)
          freal = freal1 - freal2
          fimag = fimag1 + fimag2
          ref(i)%fc = sqrt(freal**2+fimag**2)
          faze=rtod*atan2(fimag,freal)+360.0
          ref(i)%ph = mod(int(faze+0.5),360)
          !write(71,'(4i5,3f12.5,2i5)')i,ref(i)%hkl,freal,fimag,ref(i)%fc,ref(i)%ph,ref(i)%m
          write(*,'(a,2(1x,es25.17e3))') 'COMPLEX',freal,fimag
       enddo loop_riflessi1
   endif
!
   end subroutine trace_sfcalc_anis_anomal
end module phase16_trace
