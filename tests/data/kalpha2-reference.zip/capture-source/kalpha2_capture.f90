! Observation harness only: execute the retained modules without numerical substitutes.
subroutine phase12_capture() bind(C)
  use alphastrip_mod
  use variables, only: dataset
  use peak_mod
  use molcom, only: jscreen
  implicit none
  integer :: n, mode, repeats, rad, seeded, back, flag, i, j
  real :: wave
  real, allocatable :: x(:), y(:)
  read(*,*) n,mode,repeats,rad,wave,seeded,back,flag
  allocate(x(n),y(n),dataset(1))
  do i=1,n
    read(*,*) x(i),y(i)
  enddo
  jscreen=0
  call dataset(1)%set_data(x,y,n,'phase12',1)
  if(n>1) dataset(1)%tstep=(x(n)-x(1))/(n-1)
  call dataset(1)%set_wave(1,[wave])
  dataset(1)%radtype=rad
  dataset(1)%raw_y=y
  dataset(1)%alpha2_subtracted=flag==1
  if(back==1) call dataset(1)%make_background()
  if(seeded==1) call peak_set(pkind,npk=1,x=[x(max(1,n/2))],y=[100.0],fwhm=[0.1],wave=wave)
  write(*,'(a)') 'BEFORE12'
  write(*,*) numpeaks(pkind),dataset(1)%has_back(),dataset(1)%alpha2_subtracted
  do j=1,repeats
    if(mode==0) then
      call alphastrip(dataset(1))
    else
      call kalpha2_stripping()
    endif
  enddo
  write(*,'(a)') 'AFTER12'
  write(*,*) n,numpeaks(pkind),numpeaks(pkindtot),dataset(1)%has_back(), &
    dataset(1)%alpha2_subtracted,dataset(1)%back_subtracted,dataset(1)%data_scaled
  do i=1,n
    write(*,'(3(es25.17e3,1x))') dataset(1)%x(i),dataset(1)%y(i),dataset(1)%raw_y(i)
  enddo
  write(*,'(a)') 'BACKGROUND12'
  if(allocated(dataset(1)%yb)) then
    write(*,*) size(dataset(1)%yb)
    do i=1,size(dataset(1)%yb)
      write(*,'(es25.17e3)') dataset(1)%yb(i)
    enddo
  else
    write(*,*) 0
  endif
  write(*,'(a)') 'PEAKS12'
  if(allocated(pkind)) call peak_print(pkind,kpr=6)
end subroutine
