extern "C" void phase12_capture();
// Test-only presentation sink: native numerical routines remain linked unchanged.
// Calling the GUI callbacks with no MainWindow is not a numerical oracle.
extern "C" void __wrap___view_MOD_vedinew() {}
extern "C" void __wrap_update_peak_graph_() {}
int main() { phase12_capture(); }
